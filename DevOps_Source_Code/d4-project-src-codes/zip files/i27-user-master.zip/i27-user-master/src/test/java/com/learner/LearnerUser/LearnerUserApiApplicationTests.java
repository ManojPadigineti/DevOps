package com.learner.LearnerUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnerUserApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
