package com.lerner.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LernerEurekaApplicationTests {

	@Test
	void contextLoads() {
		// This test just verifies that the application context loads without errors
	}

}
