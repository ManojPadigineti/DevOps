package com.i27academy.builds;


// all the methods 
class Calculator {
    def jenkins
    Calculator(jenkins) {
        this.jenkins = jenkins
    }



// Addition Method
def add(firstNumber, secondNumber){
    // Logical code 
    return firstNumber+secondNumber
}

// Multiplication Method
def multiply(firstNumber, secondNumber){
    // Logical Code
   return firstNumber*secondNumber
}
}

