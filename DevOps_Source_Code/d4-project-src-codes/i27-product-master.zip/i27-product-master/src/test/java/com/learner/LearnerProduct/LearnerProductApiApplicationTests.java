package com.learner.LearnerProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnerProductApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
