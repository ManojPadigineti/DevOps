package com.learner.LearnerProduct.controller.productCategory.CategoryRequestBeans;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryBean {
    private String title;
    private String imageUrl;
    private String route;
}