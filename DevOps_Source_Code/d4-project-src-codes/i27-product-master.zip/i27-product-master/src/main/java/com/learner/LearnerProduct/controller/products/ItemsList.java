package com.learner.LearnerProduct.controller.products;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ItemsList {
    private String name;
    private String imageUrl;
    private int price;
}
