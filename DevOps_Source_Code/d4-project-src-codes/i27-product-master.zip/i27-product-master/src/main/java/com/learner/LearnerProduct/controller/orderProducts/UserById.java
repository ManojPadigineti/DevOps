package com.learner.LearnerProduct.controller.orderProducts;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserById {
    private String firstName;
    private String lastName;
    private String email;
}
